<!--Slider start-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="http://project1.inncrotech.site/assets/image/product_adv/V0377_Home-Main-Slider-2-Levis-500-off-20052017.jpg" alt="First slide" width="100%" class="img-responsive">
            <!-- Static Header -->

        </div>
        <div class="item">
            <img src="http://project1.inncrotech.site/assets/image/product_adv/K0730-Mens-Main-Slider-3-Brand-day-Carlton-London-Min-40-off-20052017.jpg" alt="Second slide" width="100%" class="img-responsive">

        </div>
        <div class="item">
            <img src="http://project1.inncrotech.site/assets/image/product_adv/K0730-Mens-Main-Slider-3-Brand-day-Carlton-London-Min-40-off-20052017.jpg" alt="Third slide" width="100%" class="img-responsive">

        </div>
    </div>
    <!-- Controls -->
    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
        <span class="icon-prev"></span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
        <span class="icon-next"></span>
    </a>
</div><!-- /carousel -->
<!-- End Slider -->

<div class="marketshop-banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12"><a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0046.jpg" alt="Sample Banner 2" title="Sample Banner 2"  width="100%" class="img-responsive"></a></div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12"><a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0041.jpg" alt="Sample Banner" title="Sample Banner"  width="100%" class="img-responsive"></a></div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12"><a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0039.jpg" alt="Sample Banner 3" title="Sample Banner 3"  width="100%" class="img-responsive"></a></div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12"><a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0049.jpg" alt="Sample Banner 4" title="Sample Banner 4"  width="100%" class="img-responsive"></a></div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row product_slider">
        <div class="col-md-12">
            <div id="demo">
                <div class="container-fluid">
                    <div class="row">
                        <div class="product_slider ">
                            <div class="customNavigation"> 
                                <div class="row">
                                    <div class="col-md-9 text-left">
                                        <h3 style="margin-top: 0">New Arrivals Offer</h3>
                                    </div>
                                    <div class="col-md-3"> 
                                        <a class="btn prev"><i class="fa fa-caret-left"></i></a> 
                                        <a class="btn next"><i class="fa fa-caret-right"></i></a> 
                                    </div>
                                </div>
                            </div>
                            <div id="owl-demo" class="owl-carousel">
                                <div class="item "> 
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0049.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                    <div class="col-item">
                                        <div class="photo">
                                            <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                        </div>
                                        <div class="info">
                                            <div class="col-md-12">
                                                <div class="price ">
                                                    <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                </div>
                                            </div>
                                            <div class="separator clear-left">
                                                <div class="col-md-12">
                                                    <p class="price-tag">
                                                        <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                        <span><i class="fa fa-inr"></i><span>150</span></span>
                                                        <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="clearfix">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="list-banner-adv">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="item-adv-simple">
                    <a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product_adv/ad1.jpg" alt=""  width="100%" class="img-responsive"></a>
                </div>
            </div>
            <div class="col-md-5 col-sm-5 col-xs-12">
                <div class="item-adv-simple">
                    <a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product_adv/ad2.jpg" alt=""  width="100%" class="img-responsive"></a>
                </div>
                <div class="item-adv-simple">
                    <a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product_adv/ad3.jpg" alt=""  width="100%" class="img-responsive"></a>
                </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="item-adv-simple">
                    <a href="sub_categories.php"><img src="http://project1.inncrotech.site/assets/image/product_adv/ad4.jpg" alt=""  width="100%" class="img-responsive"></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row product_slider">
        <div class="col-md-12">
          <div id="demo">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="product_slider ">
                                    <div class="customNavigation"> 
                                        <div class="row">
                                            <div class="col-md-9 text-left">
                                                <h3 style="margin-top: 0">My Fashion</h3>
                                            </div>
                                            <div class="col-md-3"> 
                                                    <a class="btn prev1"><i class="fa fa-caret-left"></i></a> 
                                                    <a class="btn next1"><i class="fa fa-caret-right"></i></a> 
                                            </div>
                                        </div>
                                    </div>
                                    <div id="owl-demo1" class="owl-carousel">
                                        <div class="item "> 
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product/IMG-20170530-WA0049.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <i class="fav fa fa-heart-o" style="font-size: 20px; margin-right: 17px;color: black;" onclick="setColor(event, 'button', '#101010')"></i>
                                            <div class="col-item">
                                                <div class="photo">
                                                    <a href="product_list.php"> <img src="http://project1.inncrotech.site/assets/image/product_adv/product4.jpg" class="img-responsive" alt="a" /></a>
                                                </div>
                                                <div class="info">
                                                    <div class="col-md-12">
                                                        <div class="price ">
                                                            <a href="product_detail.php"><h6 class="title-product">LEVI'S Light Blue Washed Low Rise Skinny Fit Jeans </h6></a>
                                                        </div>
                                                    </div>
                                                    <div class="separator clear-left">
                                                        <div class="col-md-12">
                                                            <p class="price-tag">
                                                                <span class="price_strikethrough"><i class="fa fa-inr"></i><span>200</span></span>
                                                                <span><i class="fa fa-inr"></i><span>150</span></span>
                                                                <span><a href="product_list.php"><button type="submit" class="btn btn-default shopbtn">Show Now  </button></a></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
    </div>
</div>


<style>
    .product_box {
        border: 1px solid rgba(221, 221, 221, 0.63);
        padding: 10px;
        margin-bottom: 10px;
        transition: all 0.2s ease;
        cursor: pointer;
        min-height: 320px;
        background: #fff;
    }
    .product_box:hover {
        box-shadow: 3px 4px 4px 1px #d3d3d3;
    }
    .rmv{padding:1px }
    .title-product {

        .price_strikethrough{    
            color: #1a8dbb;
            text-decoration: line-through;}
        .shopbtn{    padding: 4px 10px;
                     background: #00c1f9;
                     color: white;}
    </style>