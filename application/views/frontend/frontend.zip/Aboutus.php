
<div class="row order_box" style="border: none;">
    <section class="col-md-12">
        <div class="col-md-10 col-md-offset-1">
            <div class="" style="padding: 0">
                <div class="tab-content">
                    <div class="aboutus">
                        <div class="container">
                            <h3>About Us </h3>
                            <div class="col-md-12 col-sm-12 contain">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                                <div class="col-md-3 ftr-top-left about-text-grids">
                                    <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                    <h4>10 Million+ <br>Products</h4>
                                </div>
                                <div class="col-md-3 ftr-top-left about-text-grids">
                                    <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                    <h4>10 Million+ <br>Products</h4>
                                </div>
                                <div class="col-md-3 ftr-top-left about-text-grids">
                                    <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                    <h4>10 Million+ <br>Products</h4>
                                </div>
                                <div class="col-md-3 ftr-top-left about-text-grids">
                                    <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                                    <h4>10 Million+ <br>Products</h4>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="history">
				<h3>Our Mission</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> 
				<!---728x90---> 
				<h3 class="w3ls-title">Our History</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p> 
			</div>
                </div>
            </div>
        </div>
    </section>
</div>