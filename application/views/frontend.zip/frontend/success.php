<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$stud_details_id=$_POST["udf1"];
$fee_id=$_POST["udf2"];
$discount=$_POST["udf3"];
$penalty=$_POST["udf4"];
$invoice_number=$_POST["udf5"];
$submission_id=$_POST["address1"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$phone=$_POST["phone"];
$salt="eCwWELxi";
//pre($_POST,1);
if(isset($_POST["additionalCharges"])) {
	$additionalCharges=$_POST["additionalCharges"];
	$retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'||||||'.$invoice_number.'|'.$penalty.'|'.$discount.'|'.$fee_id.'|'.$stud_details_id.'|'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;        
}else {	 
	$retHashSeq = $salt.'|'.$status.'||||||'.$invoice_number.'|'.$penalty.'|'.$discount.'|'.$fee_id.'|'.$stud_details_id.'|'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
}
/////////////////////////////
$msg ='';
$hash = hash("sha512", $retHashSeq);		 
if ($hash != $posted_hash) {
	$msg =  "<h6 class='orange'>Invalid Transaction. Please try again</h6>";
}
else {
	$CI = & get_instance();
	$CI->load->library('cart');
	
	
	/*$html = '<div class="table-responsive">'.
		'<table style="width:100%">'.
			'<thead>';
				if ($cart = $CI->cart->contents()){
				$html .='<tr id= "main_heading">'.
					'<th style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">Product Info</th>'. 
					'<th style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">Quantity</th>'.
					'<th style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">Amount</th>'.
					'<th style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">Total</th>'.
				'</tr>'. 
			'</thead>'. 
			'<tbody>'; 
			$grand_total = 0;
			$sub_total = 0;
			foreach ($cart as $item){
			$html.='<tr>'.
				'<td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">'.$item['name'].'</td>'.
				'<td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">'.$item['qty'].'</td>'. 
				'<td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;" class="price">Rs.'.number_format($item['price'], 2).'</td>'. 
				'<td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;" class="price">Rs.'.number_format(($item['price']*$item['qty']),2).'</td>';
				$sub_total =($item['price']*$item['qty']);
                $grand_total = $grand_total + $sub_total; 
             $html.='<tr>';
}}
	'</tbody><tbody><tr><td colspan="2" style=" border: 1px solid #dddddd;text-align: left;padding: 8px;"></t ><td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">Total</td><td style=" border: 1px solid #dddddd;text-align: left;padding: 8px;">'.$grand_total.'</td></tr></tbody>'.
	$html.='</table>'.
'</div>';
echo $html;die;*/
	$CI->cart->destroy();
	$msg.= "<h6 class='orange'>Thank You. Your order status is ". $status .".</h6>";
	$msg.= "<h6 class='orange'>Your Transaction ID for this transaction is ".$txnid.".</h6>";
	$msg.= "<h6 class='orange'>We have received a payment of Rs. " . $amount . ". Your order will soon be shipped.</h6>";           
} 

?>
<!-- Middle Section Start -->
<section class="middleSection cmsSection">
	<div class="container">
		<div class="contactusSection">
			<h2 class="heading clearfix">
				<span>Payment Successfu</span>
			</h2>
			<div class="row">
				<div class="col-md-6 col-sm-6">
       
           <?php echo $msg;?>
			</div> 
			</div>
		</div> 
	</div>
</section>	