
<!-- Middle Section Start -->
<section class="middleSection cmsSection">
	<div class="container">
		<div class="contactusSection">
			<h2 class="heading clearfix">
				<span>Contact Us</span>
			</h2>
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="smallHeading">Contact Form</div>
					<form class="contactForm">
						<div class="form-group">
							<label for="exampleInputEmail1">Your name</label>
							<input type="text" class="form-control" id="" placeholder="">
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Email address</label>
							<input type="email" class="form-control" id="" placeholder="">
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Subject</label>
							<input type="text" class="form-control" id="" placeholder="">
						</div>
						<div class="form-group">
							<label for="exampleInputEmail1">Message</label>
							<textarea class="form-control"></textarea>
						</div>
						<button type="submit" class="btn purpleBtn">Submit</button>
					</form>
				</div>
				<div class="col-md-6 col-sm-6">
					<div id="map" style="width:100%;height:200px"></div>
					<div class="addInfo">
						<div class="smallHeading">Our location</div>
						<address>Address: Florisan<br/>
						B/123, ABC Apartment,<br/>
						Near ABC School,<br/>
						Pune - 411 123<br/>
						E-Mail Address: <a href="mailto:customercare@speedykick.com" target="_top">customercare@florisan.com</a><br/>
						Telephone: <a href="tel:+919876543210">+919876543210</a></address> 
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Middle Section End -->
