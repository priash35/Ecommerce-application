
<!-- Footer Start -->
<footer>
	<div class="footerTop">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3 col-xs-6">
					<ul class="clean list-unstyled">
						<li class="flHeading">Information</li>
						<li><a href="<?php echo base_url(); ?>contact">Contact us</a></li>
						<li><a href="<?php echo base_url(); ?>Careers">Careers</a></li>
						<li><a href="about-us.html">About us</a></li>
						<li><a href="#">Delivery</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6">
					<ul class="clean list-unstyled">
						<li class="flHeading">Useful Links</li>
						<li><a href="#">Terms & Conditions</a></li>
						<li><a href="#">Testimonials</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Disclaimer</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6">
					<ul class="clean list-unstyled scialIcons">
						<li class="flHeading">Like us on</li>
						<li><a href="#" class="fb"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" class="twt"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" class="inst"><i class="fa fa-instagram"></i></a></li>
						<li><a href="#" class="link"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" class="pint"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" class="gplus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
				<div class="col-md-3 col-sm-3 col-xs-6">
					<ul class="clean list-unstyled paymentOptions">
						<li class="flHeading">Payment Options</li>
						<li><a href="#"><img src="<?php echo base_url(); ?>assets/frontend/img/visa.png"></a></li>
						<li><a href="#"><img src="<?php echo base_url(); ?>assets/frontend/img/mastercard.png"></a></li>
						<li><a href="#"><img src="<?php echo base_url(); ?>assets/frontend/img/maestro.png"></a></li>
						<li><a href="#"><img src="<?php echo base_url(); ?>assets/frontend/img/paypal.png"></a></li>
						<li><a href="#"><img src="<?php echo base_url(); ?>assets/frontend/img/payu.png"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="footerBot">
		<div class="container">
			<div class="copyTxt text-center">&copy; Florisan 2017. All Rights Reserved</div>
		</div>
	</div>
</footer>
<!-- Footer End -->

<!-- Track Order Popup -->
<div class="modal fade cstmModal smallModal" id="trackOrder" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Track Order</h4>
      </div>
      <div class="modal-body">
		<form class="trackOrderForm">
		  <div class="form-group">
			<label for="">Order No</label>
			<input class="form-control" id="exampleInputEmail1" placeholder="Order No" type="text">
		  </div>
		  <div class="form-group">
			<label for="">Email ID</label>
			<input class="form-control" id="exampleInputPassword1" placeholder="Email ID" type="text">
		  </div>
		  <button type="submit" class="btn purpleBtn btn-block">Track Now</button>
		</form>
      </div>
    </div>
  </div>
</div>

<!-- Login Modal -->
<div class="modal fade cstmModal" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Login</h4>
      </div>
      <div class="modal-body">
		<div class="row lwSocialLinks">
			<div class="col-xs-6"><a href="#" class="lwFacebook"><i class="fa fa-facebook"></i> Login With Facebook</a></div>
			<div class="col-xs-6"><a href="#" class="lwGoogle"><i class="fa fa-twitter"></i> Login With Google</a></div>
		</div>
		<div class="orDivider"><span>OR</span></div>
		<form class="loginForm">
		  <div class="form-group">
			<label for="">Username</label>
			<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Username">
		  </div>
		  <div class="form-group">
			<label for="">Password</label>
			<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
		  </div>
		  <!--<div class="clearfix">
			<div class="checkbox pull-left">
				<label><input type="checkbox"> Remember me</label>
			</div>
			<a href="#" class="fogpassLink pull-right" data-toggle="modal" data-target="#forgotPassModal" data-dismiss="modal">Forgot password</a>
		  </div>-->
		  <button type="submit" class="btn purpleBtn btn-block">Login</button>
		</form>
      </div>
    </div>
  </div>
</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url(); ?>assets/frontend/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/timepicker/bootstrap-clockpicker.min.js"></script>
<script src="<?php echo base_url(); ?>assets/frontend/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>assets/frontend/js/jquery.elevatezoom.min.js"></script>

<script>
$(document).ready(function(){

/* Header Top Menu Hide/Show */
$("#slideHeaderTopMenu").click(function(){
    $(".headerRight").slideToggle();
	$("body").toggleClass("headerTopMenuOpen");
});

/* Header Bottom Menu Hide/Show */
$("#slideHeaderBotMenu").click(function(){
    $(".navbar-collapse").slideToggle();
	$("body").toggleClass("headerBotMenuOpen");
});

/* Mega Dropdown Header */
if(window.innerWidth > 768){
	$(".navMenu .dropdown").hover(function() {
		$(this).toggleClass('open');
		return false;
	});
}

if(window.innerWidth < 767){
	$(".navMenu .dropdown-toggle").click(function() {
		$(this).parent().toggleClass("open");
		return false;
	});
}
/* Fixed Filter Nav After Scroll */
$(window).bind('scroll', function() {
var navHeight = $( window ).height() - 70;
	 if ($(window).scrollTop() > navHeight) {
		 $('.filterNav').addClass('filterNavFixed');
	 }
	 else {
		 $('.filterNav').removeClass('filterNavFixed');
	 }
});

/* Tooltip */
$('[data-toggle="tooltip"]').tooltip();

/* Best Sellers Slider */
$('#bestSellerSlider').owlCarousel({
	loop:false,
	nav:true, 
	margin:15,
	dots:false,	
	navText: ["<",">"],
	responsive:{
	0:{
	  items:1,
	},
	480:{
	  items:2, 
	},
	600:{
	  items:3, 
	},
	992:{
	  items:4,
	},
	1200:{
	  items:5,
	}
  }
});

/* Birthday Slider */
$('#birthdaySlider').owlCarousel({
	loop:false,
	nav:true, 
	margin:15,
	dots:false,	
	navText: ["<",">"],
	responsive:{
	0:{
	  items:1,
	},
	480:{
	  items:2, 
	},
	600:{
	  items:3, 
	},
	992:{
	  items:4,
	},
	1200:{
	  items:5,
	}
  }
});

/* Birthday Slider */
$('#anniversarySlider').owlCarousel({
	loop:false,
	nav:true, 
	margin:15,
	dots:false,	
	navText: ["<",">"],
	responsive:{
	0:{
	  items:1,
	},
	480:{
	  items:2, 
	},
	600:{
	  items:3, 
	},
	992:{
	  items:4,
	},
	1200:{
	  items:5,
	}
  }
});

/* Gift Slider */
$('#giftSlider').owlCarousel({
	loop:false,
	nav:true, 
	margin:15,
	dots:false,	
	navText: ["<",">"],
	responsive:{
	0:{
	  items:1,
	},
	480:{
	  items:2, 
	},
	600:{
	  items:3, 
	},
	992:{
	  items:4,
	},
	1200:{
	  items:5,
	}
  }
});

/* Gift Slider */
$('#eventSlider').owlCarousel({
	loop:false,
	nav:true, 
	margin:15,
	dots:false,	
	navText: ["<",">"],
	responsive:{
	0:{
	  items:1,
	},
	480:{
	  items:2, 
	},
	600:{
	  items:3, 
	},
	992:{
	  items:4,
	},
	1200:{
	  items:5,
	}
  }
});
/* Product Image Zoom */
$("#productZoom").elevateZoom({
  zoomType: "inner",
  cursor: "crosshair"
});
});

$(document).ready(function(){ 
	$("#pincode").focusout(function(e){ 
		var pincode = jQuery("#pincode").val();
		var product_id = jQuery("#productCode").attr('rel');
		//alert(product_id);
		jQuery.ajax({
			url: "<?php echo base_url(); ?>products/check_area_availability",
			data: {pincode: pincode,product_id:product_id},
			type:"post",
			async: false,
			success:function(msg){ 
				if(msg>0){ 
					jQuery(".dstatus").html("We are unable to deliver product in your area!").css("color","red");
					return false;
				}else{
					jQuery(".dstatus").html("Delivery Available").css("color","green");
					
				}
			}
		});
	});
	$("#add_to_cart_form").submit(function(e) {  
		var flag = Array();
		var i = 0;
		var pincode = jQuery("#pincode").val();
		var product_id = jQuery("#productCode").attr('rel');
		if(pincode==''){   
			jQuery(".dstatus").html("Please enter pin code").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery.ajax({
				url: "<?php echo base_url(); ?>products/check_area_availability",
				data: {pincode: pincode,product_id:product_id},
				type:"post",
				async: false,
				success:function(msg){ 
					if(msg>0){ 
						jQuery(".dstatus").html("We are unable to deliver product in your area!").css("color","red");
							flag[i] = false;
							i++;
					}else{
						jQuery(".dstatus").html("");
						flag[i] = true;
						i++;
						
					}
				}
			});
		}
		if($("#delivery_date").val()==''){
			jQuery(".ddate").html("Please select delivery date.").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery(".ddate").html("");
			flag[i] = true;
			i++;
		}
		if($("#delivery_time").val()==''){
			jQuery(".dtime").html("Please select delivery Time.").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery(".dtime").html("");
			flag[i] = true;
			i++;
		}
	 	var n = 0;
		for(var j=0;j<flag.length;j++){
			if(flag[j] == false){
				n++;
			}else{
				
			}
		}
		if(n>0){
			return false;
		}else{
			return true;
		}
    });
	$("#buy_now_form").submit(function(e) {  
		var flag = Array();
		var i = 0;
		var pincode = jQuery("#pincode").val();
		var product_id = jQuery("#productCode").attr('rel');
		if(pincode==''){   
			jQuery(".dstatus").html("Please enter pin code").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery.ajax({
				url: "<?php echo base_url(); ?>products/check_area_availability",
				data: {pincode: pincode,product_id:product_id},
				type:"post",
				async: false,
				success:function(msg){ 
					if(msg>0){ 
						jQuery(".dstatus").html("We are unable to deliver product in your area!").css("color","red");
							flag[i] = false;
							i++;
					}else{
						jQuery(".dstatus").html("");
						flag[i] = true;
						i++;
						
					}
				}
			});
		}
		if($("#delivery_date").val()==''){
			jQuery(".ddate").html("Please select delivery date.").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery(".ddate").html("");
			flag[i] = true;
			i++;
		}
		if($("#delivery_time").val()==''){
			jQuery(".dtime").html("Please select delivery Time.").css("color","red");
			flag[i] = false;
			i++;
		}else{
			jQuery(".dtime").html("");
			flag[i] = true;
			i++;
		}
		var n = 0;
		for(var j=0;j<flag.length;j++){
			if(flag[j] == false){
				n++;
			}else{
				
			}
		}
		if(n>0){
			return false;
		}else{
			return true;
		}
	});
});
$('.datepicker').datepicker({
    format: 'dd-mm-yyyy',
    startDate: '+2d'
});
$('.clockpicker').clockpicker();
</script>
<!-- Google Map Start -->
<script>
function myMap() {
	var mapCanvas = document.getElementById("map");
	var mapOptions = {
	center: new google.maps.LatLng(18.5246164, 73.8629674),
	zoom: 10
}
	var map = new google.maps.Map(mapCanvas, mapOptions);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?callback=myMap"></script>
<!-- Google Map End -->
</body>
</html>