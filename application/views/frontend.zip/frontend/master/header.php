<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Florisan">
<meta name="keywords" content="Florisan">
<link rel="author" href="https://www.google.co.in/" />
<title>Florisan - Home</title>
<style>
.mine{
 font-size: 9px;
    line-height: 0.9;
    padding: 2px 3px;
    position: absolute;
    text-align: center;
    top: 59px;
	}
</style>
<?php
	$CI = & get_instance();
	$CI->load->library('cart');
	$cart = $CI->cart->contents();
	$total = 0;	
	$qty = 0;
	foreach($cart as $item){
		$total = ($total+$item['qty']);
	}

?>
<!-- CSS & Fonts Start -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet"><!-- Open Sans Google Font -->
<link href="<?php echo base_url(); ?>assets/frontend/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datepicker/datepicker3.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/timepicker/bootstrap-clockpicker.min.css">
<link href="<?php echo base_url(); ?>assets/frontend/css/main.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/frontend/css/responsive.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/frontend/css/font-awesome.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/frontend/css/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/frontend/css/owl.theme.default.min.css" rel="stylesheet">
<!-- CSS & Fonts End -->

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>

<!-- Header Start -->
<header><?php //echo '<pre>'; print_r($catArray); ?>
	<div class="container">
		<div class="logo pull-left">
			<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/frontend/img/logo.png" alt="Florisan Logo" title="Florison"></a>
		</div>
		<div class="mobBtns pull-right"><!-- Mobile Buttons Start -->
			<a href="#" id="slideHeaderTopMenu"><i class="fa fa-ellipsis-v"></i></a>
			<a href="#" id="slideHeaderBotMenu"><i class="fa fa-bars"></i></a>
		</div><!-- Mobile Buttons End -->
		<div class="headerRight pull-right"><!-- Header Right Start -->
			<div class="headerRightTop clearfix">
				<!--<div class="hrInput">
					<div class="input-group">
						<span class="input-group-addon"><img src="<?php echo base_url(); ?>assets/frontend/img/clock-icon.png"></span>
						<input type="text" class="form-control" placeholder="Enter Pincode for Same Day Delivery">
					</div>
				</div>-->
				<div class="hrInput pull-right">
					<form class="searchForm">
						<div class="input-group">
							<span class="input-group-addon"><img src="<?php echo base_url(); ?>assets/frontend/img/search-icon.png"></span>
							<input type="text" class="form-control" placeholder="Search...">
						</div>
					</form>
				</div>
			</div>
			<div class="headerRightBot pull-right clearfix">
				<ul class="clean list-unstyled headerMenus">
					<li><a href="<?php echo base_url(); ?>Products/corporate"><img src="<?php echo base_url(); ?>assets/frontend/img/corporate-icon.png"> Corporate</a></li>
					<li><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/frontend/img/home-icon.png"> Home</a></li>
					<li><a href="<?php echo base_url(); ?>shopping"><img src="<?php echo base_url(); ?>assets/frontend/img/cart-icon.png"> Cart<?php if($total>0){ ?><span class="label mine label-warning"><?php echo $total;?></span><?php } ?></a></li>
					<li><a href="#" data-toggle="modal" data-target="#trackOrder"><img src="<?php echo base_url(); ?>assets/frontend/img/track-order-icon.png"> Track Order</a></li>
					<li><a href="<?php echo base_url(); ?>contact"><img src="<?php echo base_url(); ?>assets/frontend/img/help-icon.png"> Help</a></li>
					<li><a href="#" data-toggle="modal" data-target="#loginModal"><img src="<?php echo base_url(); ?>assets/frontend/img/profile-icon.png"> Account</a></li>
				</ul>
			</div>
		</div><!-- Header Right End -->
	</div>
</header>
<!-- Header End -->

<!-- Navigation Start -->
<nav class="navbar-collapse js-navbar-collapse">
	<div class="container">
		<ul class="clean nav nav-justified navMenu">
		<?php foreach($catArray as $CA){ ?>
			<li class="dropdown mega-dropdown "><!-- Best Sellers Start -->
				<?php if($CA['CT']=='Best Sellers'){ $aImg='sellers-icon.png';}elseif($CA['CT']=='Birthday'){$aImg='cake-icon.png';}elseif($CA['CT']=='Anniversary'){$aImg='ring-icon.png';}elseif($CA['CT']=='Gifts'){$aImg='ribbon-icon.png';}elseif($CA['CT']=='Occasions'){$aImg='sale-icon.png';}else{$aImg='valentinehearticon.png';} ?>
				<a href="<?php if(count($CA['CatList'])==0){ echo base_url()."home"; } ?>" class="dropdown-toggle"><img src="<?php echo base_url(); ?>assets/frontend/img/<?=$aImg?>"> <?=$CA['CT']?></a>				
				<?php if(count($CA['CatList'])!=0){ ?>
				<ul class="dropdown-menu mega-dropdown-menu">
					<?php 
						foreach($CA['CatList'] as $CL){
							 //echo '<pre>'; //print_r($subCatL);
							    $sql ="SELECT * FROM sub_categories where sc_category_fk_id=".$CL['category_pk_id'];
								$query = $this->db->query($sql);
									
							?>
					<li class="col-sm-3 col-xs-3">
							
						
						<ul>
							<li class="dropdown-header"><?=$CL['category_name']?></li>
							<? if ($query->num_rows() > 0) {
								foreach ($query->result() as $SBL) { 
								
								?>
								
							<li><a href="<?php echo base_url(); ?>Products/Category/<?php echo $SBL->sc_category_name;?>/<?php echo $SBL->sc_pk_id;?>"><?php echo $SBL->sc_category_name;?> </a></li> <?php  } } ?>
							
						</ul>
					</li>	
					<?php }
					
					?>
					
					
				</ul>	<?php } ?>			
			</li><!-- Best Sellers End -->
		<?php } ?>
		</ul>
	</div>
</nav>
<!-- Navigation End -->