<!-- Middle Section Start -->
<section class="middleSection cmsSection">
	<div class="container">
		<div class="contactusSection">
			<h2 class="heading clearfix">
				<span>Contact Us</span>
			</h2>
			<div class="row">
				<div class="col-md-6 col-sm-6">
       
            <?php
            // this will show you thank you message.
            echo "<h1 align='center'>Thank You! your order has been placed!</h1>";
            echo "<span id='go_back'><a class='fg-button teal' href=" . base_url() . "index.php/shopping>Go back</a></span>";
				?>
			</div> 
			</div>
		</div> 
	</div>
</section>	