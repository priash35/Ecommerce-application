<?php
$Id = $this->uri->segment('3');
$getId = $Id!="" ? $Id : '0';

$product_name  = '';
$product_desc  = '';
$selected_area_id ='';
$category_id  = '';
$isActive = '';
$product_image='';
$price='';
$sub_category_id ='';
$selected_area =array('0');
$actionMsg = "Add";
$btnMsg = "Save";
$delInfo ='';
$care='';
$SUK = '';
$brand_pk_id = '';
$sc_category_fk_id = ''; $city_pk_id = ''; $vendor_pk_id = '';
if(isset($getproduct) && !empty($getproduct)) { 
   $actionMsg = "Update";
   $btnMsg = "Update";
   $product_name = $getproduct->product_name!="" ? $getproduct->product_name : '';
   $product_desc = $getproduct->product_desc!="" ? $getproduct->product_desc : '';
   $category_id = $getproduct->category_fk_id!="" ? $getproduct->category_fk_id : '';
   $sub_category_id = $getproduct->sub_category_fk_id!="" ? $getproduct->sub_category_fk_id : '';
   $price=$getproduct->price!="" ? $getproduct->price : '';
   $product_image=$getproduct->product_image!="" ? $getproduct->product_image : '';
   $isActive = $getproduct->product_status!="" ? $getproduct->product_status : '';
   $selected_area_id = $getproduct->area_fk_id!="" ? $getproduct->area_fk_id : '';
   $delInfo =$getproduct->delInfo!="" ? $getproduct->delInfo : ''; 
   $care =$getproduct->care!="" ? $getproduct->care : '';
   $selected_area = explode(",",$getproduct->area_fk_id);
   $SUK = $getproduct->SUK;
   $city_pk_id = '';
}
print_r($brandList);
?>
<script>
 
</script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Add New Product
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Product Management</a></li>
            <li class="active">Add Product</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Product Details</h3>
                    </div>
                   <form method="post" id="productvalidator" enctype="multipart/form-data">
                        <div class="box-body ">
                            <div class="col-md-12">
                                <div class="form-horizontal">
                                    <div class="box-body">
                                        <div class="form-group col-md-6">
                                            <label class="col-sm-5 text-left">Item Code</label>
                                            <div class="col-sm-7">
                                               	<input type="text" id="SUK" name="SUK" value="<?php echo $SUK ?>" class="form-control validate[required,maxSize[50]]" placeholder="Item Code">
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="col-sm-5 text-left">Product Name</label>
                                            <div class="col-sm-7">
                                                <input type="text" id="product_name" name="product_name" value="<?php echo $product_name ?>" class="form-control validate[required,maxSize[50],custom[onlyLetter]]" placeholder="Product Name">
												<input type="hidden" name="id" id="id" value="<?php echo $getId; ?>">
												<input type="hidden" name="action" id="action" value="<?php echo $actionMsg; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="col-sm-5 text-left">Product Brand</label>
                                            <div class="col-sm-7">
                                                <select name="brand" class="form-control">
                                                    <option value="">-- Please Select --</option>
													<?php if(count($brandList) > 0) {
														foreach($brandList as $resultbrandList) { ?>
													   
														<option   value="<?=$resultbrandList['brand_pk_id']?>" <?php if($resultbrandList['brand_pk_id']==$brand_pk_id){ echo "selected"; }?> ><?=$resultbrandList['brand_name']?></option>
														<?php } 
													} ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="col-sm-5  text-left">Product Category</label>
                                            <div class="col-sm-7">
                                               <select class="form-control validate[required]" name="category_id" id="category_id" >
												 <option value="">----- Select Category-----</option>
												<?php if(count($category_data) > 0) {
												foreach($category_data as $resultcat) { ?>
											   
												<option   value="<?=$resultcat['category_pk_id']?>" <?php if($resultcat['category_pk_id']==$sc_category_fk_id){ echo "selected"; }?> ><?=$resultcat['category_name']?></option>
												<?php } } ?>
											</select>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Product Sub Category</label>
                                            <div class="col-sm-7">
                                                <span id="sub_category">
													<?php if(isset($actionMsg) && $actionMsg=="Update"){ ?>
														
														<select  class="form-control validate[required]" name="sub_cat" id="sub_catid" >
															<option value="" >--Select Sub Category--</option>
															<?php
															if(count($subcategory_data)>0){
																foreach($subcategory_data as $result){ 
																	if($result['sc_pk_id']== $sc_category_name){
																		$selected = 'selected';
																	}else{
																		$selected = ''; 
																	}
																	?>
																	<option value="<?php echo $result['sc_pk_id']; ?>" <?php echo $selected;?>><?php echo ucfirst($result['sc_category_name']); ?></option>
																	<?php
																}
															} ?>
														</select>
													<?php } ?>
												</span>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label class="col-sm-5 text-left">Product SubSub Category</label>
                                            <div class="col-sm-7">
                                                <span id="size_category">
													<?php if(isset($actionMsg) && $actionMsg=="Update"){ ?>
														
														<select required class="form-control validate[required]" name="size_cat" id="size_cat" >
															<option value="" >--Select Sub Sub Category--</option>
															<?php
															if(count($sizecategory_data)>0){
																foreach($sizecategory_data as $result){ 
																	if($result['sz_pk_id']== $sz_category_name){
																		$selected = 'selected';
																	}else{
																		$selected = '';
																	}
																	?>
																	<option value="<?php echo $result['sz_pk_id']; ?>" <?php echo $selected;?>><?php echo ucfirst($result['sz_category_name']); ?></option>
																	<?php
																}
															} ?>
														</select>
													<?php } ?>
												</span>
                                            </div>
                                        </div>

                                        <div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Product Description</label>
                                            <div class="col-sm-7">
                                               
												<textarea name="product_desc" class="form-control validate[required]" placeholder="Product Description"><?php echo $product_desc; ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Product Stock Qty</label>
                                            <div class="col-sm-7">
                                               <input type="text" class="form-control " name="QTY" placeholder="Stock Qty">
                                            </div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Product Color</label>
                                            <div class="col-sm-7">
                                               <select class="form-control" name="product_color">
                                                 <option value="">-- Select Color --</option>
                                                    <option value="Red">Red</option>
                                                    <option value="BLue">BLue</option>
                                                    <option value="Grean">Grean</option>
                                                </select>
                                            </div>
                                        </div>
										<div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Vendor</label>
                                            <div class="col-sm-7">
                                               <select class="form-control" name="vendor_pk_id">
                                                 <option value="">-- Select Vendor --</option>
                                                  <?php   if(count($vendor_data)>0){
																foreach($vendor_data as $result){ 
																	if($result['vendor_pk_id']== $vendor_pk_id){
																		$selected = 'selected';
																	}else{
																		$selected = '';
																	}
																	?>
																	<option value="<?php echo $result['vendor_pk_id']; ?>" <?php echo $selected;?>><?php echo ucfirst($result['bus_name']); ?></option>
																	<?php
																}
															} ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12" style="padding: 0">
                                          <label class="col-sm-5 text-left">Product Size and Price :</label>
                                            <div class="box-body">
											  <table class="table table-bordered text-center">
												<tbody><tr>
												  <th>Product Size Name</th>
												  <th>Product Unit Price</th>
												  <th>Product Discount (%)</th>
												  <th>Product Discount Price</th>
												</tr>
												<tr>
												  <td>X</td>
												  <td><input name="psXprice" type="text" class="form-control text-center"  placeholder="Unit Price"></td>
												  <td><input name="psXdic" type="text" class="form-control text-center"  placeholder="Discount (%)"></td>
												  <td><span class="badge bg-red"><i class="fa fa-rupee"></i> 55</span></td>
												</tr>
												<tr>
												  <td>XX</td>
												  <td><input name="psXXprice"  type="text" class="form-control text-center"  placeholder="Unit Price"></td>
												  <td><input name="psXXdic" type="text" class="form-control text-center"  placeholder="Discount (%)"></td>
												  <td><span class="badge bg-red"><i class="fa fa-rupee"></i> 55</span></td>
												</tr>
												<tr>
												  <td>XL</td>
												<td><input name="psXLprice" type="text" class="form-control text-center"  placeholder="Unit Price"></td>
												  <td><input name="psXLdic" type="text" class="form-control text-center"  placeholder="Discount (%)"></td>
												  <td><span class="badge bg-red"><i class="fa fa-rupee"></i> 55</span></td>
												</tr>
												<tr>
												  <td>M</td>
												  <td><input name="psMprice" type="text" class="form-control text-center"  placeholder="Unit Price"></td>
												  <td><input name="psMdic" type="text" class="form-control text-center"  placeholder="Discount (%)"></td>
												  <td><span class="badge bg-red"><i class="fa fa-rupee"></i> 55</span></td>
												</tr>
											  </tbody></table>
											</div>
                                           <div class="box-body col-md-10 input_fields_wrap">
                                             <label for="inputEmail3" class="col-sm-10 text-left">Product Delivery Charge</label>
                                            
                                                <table  class="table table-bordered ">
														<tr>
                                                            <th>City</th>
                                                            <th>Area pin Code</th>
                                                            <th>Delivery Charge</th>
                                                            <th>Aciton</th>
                                                        </tr>
                                                    <tbody id="appendArea" class="asdf">
														
                                                        <tr id="ss" rel="0" class="abc">
                                                            <td>
															<select id="" class="city_id form-control validate[required]" name="cityid_0"> 
															<option value="">-- Please Select City --</option>
															<?php
															if(count($CityData)>0){
																foreach($CityData as $result){ 
																	if($result['city_pk_id']== $city_pk_id){
																		$selected = 'selected';
																	}else{
																		$selected = '';
																	}
																	?>
																	<option value="<?php echo $result['city_pk_id']; ?>" <?php echo $selected;?>><?php echo ucfirst($result['city_name']); ?></option>
																	<?php
																}
															} ?>
															
															</select></td>
                                                            <td>
															<span id="AreaID">
															<select class="form-control validate[required]" name="area_0">
                                                    <option value="">-- Please Select Area Pin code--</option>
                                                </select>
												
												<span></td>
                                                            <td id="" class="areaClass"> <input type="number" name="delivery_charges_0" class="form-control"  placeholder="Delivery Charge"></td>
															<td id="areaID_0" ><a onclick="addMore(0)" id="addmoreArea"  class="addmoreArea btn btn-social-icon btn-primary"><i class="fa fa-plus"></i></a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <div class="form-group col-md-6">
                                            <label for="inputEmail3" class="col-sm-5 text-left">Product Image</label>
                                            <div class="col-sm-7">
                                                <input type="file" name="product_image">
                                            </div>
											
									
								</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="box-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        </div>
                    </form>
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    .boxs{
        display: none;
    }
</style>


<script>
function display(obj,a){
	
	var CITY = obj.value;
	if(CITY==''){
		$('#AreaID'+a).html('');
	} else{
		$.ajax({
			type: "POST",
			data: {CITY:CITY,a:a},
			url: url+'ajax/append_Area_addproduct',
			success: function(data) { 
				$('#AreaID'+a).html('');
				//alert($(".city_id").next().find('.AreaID').value);
				//$("#city1").next().find('.AreaID').append(data);
				$('#AreaID'+a).append(data);
			}
		});
	} 
}
function addMore(a){
	//alert(a);
	$('#areaID_'+a).css('display','none');
	a=a+1;
	var areaHtml= '<tr><td><select onchange="display(this,'+a+');" id="city'+a+'" name="cityid_'+a+'" class="city_id form-control validate[required]"><option value="">-- Please Select City --</option><?php if(count($CityData)>0){ foreach($CityData as $result){ if($result["city_pk_id"]== $city_pk_id){ $selected = "selected"; }else{ $selected = ""; }?><option value="<?php echo $result["city_pk_id"]; ?>" <?php echo $selected;?>><?php echo ucfirst($result["city_name"]); ?></option><?php } }?></select></td>';
		areaHtml+= '<td><span id="AreaID'+a+'" class="AreaID"><select class="form-control validate[required]" name="area_'+a+'"><option value="">-- Please Select Area Pin code--</option></select><span></td>';
		areaHtml+= '<td id="" class="areaClass"> <input type="number" name="delivery_charges_'+a+'" class="form-control"  placeholder="Delivery Charge"></td>';
		areaHtml+= '<td id="areaID_'+a+'" ><a onclick="addMore('+a+')" id="addmoreArea" class="addmoreArea btn btn-social-icon btn-primary"><i class="fa fa-plus"></i></a></td>';
		areaHtml+= '</tr>';
	$('#appendArea').append(areaHtml);
	
}
/* 
$("#addmoreArea").click(function(){ 
	
	var par = $(this).parent().parent().attr('rel');
	var className = $("#areaID_"+par).attr('id');
 
	$('#'+className).children().removeAttr("id");
		
	var par1 = par+1;
	var newRow ='<tr id="ss"  class="abc" rel="'+par1+'" ><td><select id="CityID" class="form-control validate[required]"><option value="">-- Please Select City --</option>';
	var newRoe='<?php if(count($CityData)>0){ 	foreach($CityData as $result){ 	if($result["city_pk_id"]== $city_pk_id){ 	$selected = "selected";	}else{	$selected = "";	}	?>';
	var newRow2='<option value="<?php echo $result["city_pk_id"]; ?>" <?php echo $selected;?>><?php echo ucfirst($result["city_name"]); ?></option><?php }	} ?>';
					
	var newRow3='</select></td>	<td><span id="AreaID"><select class="form-control validate[required]" name="area['+par1+']"><option value="">-- Please Select Area Pin code--</option></select><span></td><td class="areaClass"> <input type="number" class="form-control"  placeholder="Delivery Charge"></td><td id="areaID_'+par1+'"><a id="addmoreArea" class="btn btn-social-icon btn-primary"><i class="fa fa-plus"></i></a></td></tr>"';
    var areaHtml = (newRow+newRoe+newRow2+newRow3);
	$('#appendArea').append(areaHtml);
});
 *//*function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function (e) {
			$('#appended_logo').show();
			$('#product_photo_old').hide();
			$('#appended_logo').attr('src', e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}

$("#product_image").change(function(){
    readURL(this);
});*/ 
$("#category_id").change(function() {  
	var mydata = $(this).val();
	if(mydata==''){
		$('#sub_category').html('');
	} else{
		$.ajax({
			type: "POST",
			data: {mydata:mydata},
			url: url+'ajax/append_subcategory_addproduct',
			success: function(data) { 
				$('#sub_category').html('');
				$('#sub_category').append(data);
				$('select#sub_catidXYZ').on('change', function () {
					var mydata1 = $(this).val();
					if(mydata==''){
						$('#size_category').html('');
					} else{
						$.ajax({
							type: "POST",
							data: {mydata1:mydata1},
							url: url+'ajax/append_sizecategory_addproduct',
							success: function(data) { 
								$('#size_category').html('');
								$('#size_category').append(data);
							}
						});
					} 
				});
			}
		});
	}
	
});
$('select.city_id').on('change', function () { //alert();
					var CITY = $(this).val();
					if(CITY==''){
						$('#AreaID').html('');
					} else{
						$.ajax({
							type: "POST",
							data: {CITY:CITY,a:0},
							url: url+'ajax/append_Area_addproduct',
							success: function(data) { 
								$('#AreaID').html('');
								$('#AreaID').append(data);
							}
						});
					} 
				});

</script>