<link rel="stylesheet" href="<?php echo base_url(); ?>assets/js/function.js">


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            User Order Management
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">User Order Management</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">User Order List</h3>

                        <div class="row" style="margin-top: 10px">
                            <div class="col-sm-6 col-xs-6 ">
                                <div class="dataTables_length" id="example1_length">
                                    <label>Show <select name="example1_length" aria-controls="example1" class="form-control input-sm">
                                            <option value="10">10</option>
                                            <option value="25">25</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                        entries
                                    </label>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xs-6">
                                <div id="example1_filter" class="dataTables_filter">
                                    <label>
                                        <div class="input-group input-group-sm" style="width: 150px;">
                                            <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                                            <div class="input-group-btn">
                                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding table-striped table-bordered">
                        <div class="col-md-12">
                            <table class="table table-responsive">
                                <tr>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>Order ID</th>
                                    <th>Ship Slot</th>
                                    <th>Delivery <br>Charge</th>
                                    <th>Ship Address</th>
                                    <th>Discount <br>Amt</th>
                                    <th>Coupon<br>Discount</th>
                                    <th>Delivery Status</th>
                                    <th>Action</th>
                                </tr>
								<?php
								$cnt = 1;
								if(count($orderData) > 0) {
								foreach($orderData as $result) { //Print_r($result);?>
								
								  <tr>
									<td><?php echo $cnt; ?></td>
									<td><?php echo $result['rname']; ?></td>
									<td><?php echo ucwords($result['orderid']); ?></td>
									 <td>13-06-2017</td>
									 <td><i class="fa fa-rupee"></i> 20</td>
									<td><?php echo $result['deliveryadd']; ?></td>
									<td><i class="fa fa-rupee"></i> 20</td>
									<td><i class="fa fa-rupee"></i> 20</td>
									<?php 
										$sql = 'Select * from order_track_status where statusId='.$result['ord_status'];
										$query = $this->db->query($sql);
										$row = $query->result();
										
									?>
									
									<td><a href="" id="odrstatus" data-toggle="modal" data-target="#orderstatusModal"><?php echo $row[0]->trackstatus; ?></a></td>
									<script>
									$("#odrstatus").click(function(){
										$("#odrField").val('<?=$result['orderid']?>');
									});
									</script>
									<td><a href="<?=base_url()?>orders/products/<?=$result['orderid']?>" >View</a></td>
								  </tr>
								<?php $cnt++; } } else { ?>
								
								<?php } ?>
                                 
                                 
                            </table>

                            <div class="box-footer clearfix">
                                <ul class="pagination pagination-sm no-margin pull-right">
                                    <li><a href="#">&laquo;</a></li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">&raquo;</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>


<script>

function delvenuealert(){
	swal("Can't delete! You can't delete yourself.")
}
function delproduct(id) {
	swal({
			  title: "Are you sure you want to delete Product?",
			  text: "You will not be able to recover this record!",
			  type: "warning",
			  showCancelButton: true,
			  confirmButtonColor: "#DD6B55",
			  confirmButtonText: "Yes, delete it!",
			  closeOnConfirm: false
			},
		 
	function(){
		 $.ajax({
            type: "POST",
            data: {id:id},
            url: url+'ajax/delete_product',
            success: function(data) { 
	            if(data >0)
	            {
				    swal("Deleted!", "Product has been deleted.", "success");
		            window.location.href = url+"product/product_list/delete_success";
	            } else {
	               swal("Oops...", "Error in delete product!", "error");
				   window.location.href = url+"product/product_list";
                }
            }
        });
		
	});
}

function status_change(id,status){
	 if(status == 1) {
		var stc = 'Inactive';
	} else {
		var stc = 'Active';
	}
	swal({
	  title: "Are you sure to do product "+stc+"?",
	  //text: "You will not be able to recover this record!",
	  type: "warning",
	  showCancelButton: true,
	  confirmButtonColor: "#DD6B55",
	  confirmButtonText: "Yes,Change Status!",
	  closeOnConfirm: false
	},
	function(){	 
		jQuery.ajax({
			url: url+"ajax/product_status_change",
			type: "post",
			data:{id:id,status:status},
			success:function(msg){ 
				 window.location.href = url+"product/product_list/update_status";
			}
		});
	});
    return false;
 }

</script>