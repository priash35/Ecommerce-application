<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_Model {
 
	 public function __construct(){
	  parent::__construct();
      $this->load->helper(array('form', 'url'));
	 }
	 function is_user_logedin_withotp(){
		$where = array('user_pk_id'=>$_SESSION['front_user_logged_in']['USER_SESS_ID']);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		return ($response->LOTP);
	 } 
	function check_emailid_exist($email){
		$where = array('user_email'=>$email);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	 }
	 function get_details_OTP($otp,$HEmail){
		$where = array('OTP'=>$otp,'user_email'=>$HEmail);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		
		if(isset($response->user_pk_id)&&($response->user_pk_id!='')){
			$data = array('user_status'=>1,'OTP'=>0);
			
			$where = array('user_pk_id'=>$response->user_pk_id);
			$this->db->update('users', $data, $where);
			$res = $this->db->affected_rows();
			if ($res == 1){
				echo $response->user_pk_id; die;
			}else{
				echo $response->user_pk_id; die;
			}
		}else{
			echo 0; die;
		}
		
	 }
	 function get_details_LOTP($otp){
		$where = array('LOTP'=>$otp,'user_pk_id'=>$_SESSION['front_user_logged_in']['USER_SESS_ID']);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		
		if(isset($response->user_pk_id)&&($response->user_pk_id!='')){
			$data = array('user_status'=>1,'OTP'=>0);
			
			$where = array('user_pk_id'=>$response->user_pk_id);
			$this->db->update('users', $data, $where);
			$res = $this->db->affected_rows();
			if ($res == 1){
				echo $response->user_pk_id; die;
			}else{
				echo $response->user_pk_id; die;
			}
		}else{
			echo 0; die;
		}
		
	 }
	function check_user_emailid_exist($email,$action,$id){
	    if($action=='Add'){
			$where = array('user_email'=>$email);
	    }else{
			$where = array('user_email'=>$email,'user_pk_id!='=>$id);
		}
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	}
	//user contact exist or not
	function check_contact_exist($contact,$id,$action){
		if($action=='Add'){
			$where = array('user_contact'=>$contact);
		}else{
			$where = array('user_contact'=>$contact,'user_pk_id!='=>$id);
		}
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	}
	function update_password($data,$id){
        $where = array('user_pk_id'=>$id);
		$this->db->update('users', $data, $where);
        return $this->db->affected_rows();
	}
	//check password exist or not
	function check_password_exist($pass,$id){
		$where = "user_password='".MD5(trim($pass))."' And user_pk_id ='".$id."'";
		$this->db->select('*');
        $getSqlRes = $this->db->get_where('users',$where);
		$response = $getSqlRes->row();
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	}
	//get user list
	function get_user_list(){
		$where = array('users.user_type'=>0);
		$query =$this->db->select('users.*,status.*')
				->from('users')
				->join('status','status.status_pk_id = users.user_status')
				->where($where)
				->get();
		return $result = $query->result_array();
	}
	//get get_subc_list list
	function get_subc_list(){
		$where = array();
		$query =$this->db->select('subcription.*')
				->from('subcription')
				 
				->where($where)
				->get();
		return $result = $query->result_array();
	}
	//get user list
	function get_active_user_list(){
		$where = array('users.user_status'=>1);
		$query =$this->db->select('users.*,status.*')
				->from('users')
				->join('status','status.status_pk_id = users.user_status')
				->where($where)
				->get();
		return $result = $query->num_rows();
	}
	
	function get_Vendors_list(){
		$where = array( 'users.user_type'=>3 );
		$query =$this->db->select('users.*,vendors.* ,status.* ')
				->from('users')
				->join('vendors','vendors.User_fk_id = users.user_pk_id')
				  ->join('status','status.status_pk_id = users.user_status')
				->where($where)
				->get();
		return $result = $query->result_array();
	}
	
	function add_user($data){
		$insert = $this->db->insert('users',$data);
        return $this->db->insert_id();
	}
	function add_vendor($data){
		$insert = $this->db->insert('vendors',$data);
        return $this->db->insert_id();
	}
	//delete user
	function delete_user($id){
		$this->db->delete('users', array('user_pk_id' => $id)); 
		return $this->db->affected_rows();
	}
	//delete vendor
	function delete_vendor($id){
		$this->db->delete('vendors', array('vendor_pk_id' => $id)); 
		return $this->db->affected_rows();
	}
	//get user by id 
	function get_user_byid($id){
		$where = array('user_pk_id'=>$id);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('users',$where);
		return $response = $getSqlRes->row();
	}
	//get userID by vendor id 
	function getUserIDBYvendorID($id){
		$where = array('vendor_pk_id'=>$id);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('vendors',$where);
		return $response = $getSqlRes->row();
	}
	//update vendor
	function edit_vendor($data,$id){
		$where = array('vendor_pk_id'=>$id);
		$this->db->update('vendors', $data, $where);
        return $this->db->affected_rows();
	}//update user
	function edit_user($data,$id){
		$where = array('user_pk_id'=>$id);
		$this->db->update('users', $data, $where);
        return $this->db->affected_rows();
	}
	//update status
	function change_user_status($id,$status){
		$user_status = ($status==1)?2:1;
		$data = array('user_status'=>$user_status);
		$where = array('user_pk_id'=>$id);
		$this->db->update('users', $data, $where);
        return $this->db->affected_rows();
	}
	//update status
	function vendor_status_change($id,$status){
		$user_status = ($status==1)?2:1;
		$data = array('user_status'=>$user_status);
		$where = array('user_pk_id'=>$id);
		$this->db->update('users', $data, $where);
        return $this->db->affected_rows();
	}
	//get all area
	function get_area_list(){
		$where = array();
		$query =$this->db->select('area.*,status.*')
				->from('area')
				->join('status','status.status_pk_id = area.area_status')
				->where($where)
				->get();
		return $result = $query->result_array();
		
	}
	function get_area_list_BY_CITYid($id){
		$where = array('city_id'=>$id);
		$query =$this->db->select('area.*,status.*')
				->from('area')
				->join('status','status.status_pk_id = area.area_status')
				->where($where)
				->get();
		return $result = $query->result_array();
		
	}
	//get all city
	function get_city_list(){
		$where = array();
		$query =$this->db->select('city.*,status.*')
				->from('city')
				->join('status','status.status_pk_id = city.city_status')
				->where($where)
				->get();
		return $result = $query->result_array();
		
	}
	//add area 
    function add_area($data){
		$insert = $this->db->insert('area',$data);
        return $this->db->insert_id();
	}
	//update area
	function edit_area($data,$id){
		$where = array('area_pk_id'=>$id);
		$this->db->update('area', $data, $where);
        return $this->db->affected_rows();
	}//add area 
    function add_city($data){
		$insert = $this->db->insert('city',$data);
        return $this->db->insert_id();
	}
	//update area
	function edit_city($data,$id){
		$where = array('city_pk_id'=>$id);
		$this->db->update('city', $data, $where);
        return $this->db->affected_rows();
	}
	function change_area_status($id,$status){
		$area_status = ($status==1)?2:1;
		$data = array('area_status'=>$area_status);
		$where = array('area_pk_id'=>$id);
		$this->db->update('area', $data, $where);
        return $this->db->affected_rows();
	}
	function change_city_status($id,$status){
		$city_status = ($status==1)?2:1;
		$data = array('city_status'=>$city_status);
		$where = array('city_pk_id'=>$id);
		$this->db->update('city', $data, $where);
        return $this->db->affected_rows();
	}
	function get_area_by_id($id){
		$where = array('area_pk_id'=>$id);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('area',$where);
		return $response = $getSqlRes->row();
	}function get_city_by_id($id){
		$where = array('city_pk_id'=>$id);
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('city',$where);
		return $response = $getSqlRes->row();
	}
	function check_area_exist($area_name,$action,$id){
		if($action=='Add'){
			$where = array('LOWER(area_name)'=>$area_name);
		}else{
			$where = array('LOWER(area_name)'=>$area_name,'area_pk_id!='=>$id);
		}
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('area',$where);
		$response = $getSqlRes->row();
//echo $this->db->last_query();exit;
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	}
	function check_city_exist($city_name,$action,$id){
		if($action=='Add'){
			$where = array('LOWER(city_name)'=>$city_name);
		}else{
			$where = array('LOWER(city_name)'=>$city_name,'city_pk_id!='=>$id);
		}
		$this->db->select('*');        
        $getSqlRes = $this->db->get_where('city',$where);
		$response = $getSqlRes->row();
//echo $this->db->last_query();exit;
		if(count($response)>0){
			return 1;
		}else{
			return 0;
		}
	}
	function delete_area($id){
		$this->db->delete('area', array('area_pk_id' => $id)); 
		return $this->db->affected_rows();
	}function delete_city($id){
		$this->db->delete('city', array('city_pk_id' => $id)); 
		return $this->db->affected_rows();
	}
}
?>
